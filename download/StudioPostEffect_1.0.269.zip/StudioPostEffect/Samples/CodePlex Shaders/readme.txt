All the shaders in this directory branch come from CodePlex web site.
[Windows Presentation Foundation Pixel Shader Effects Library]
http://wpffx.codeplex.com
