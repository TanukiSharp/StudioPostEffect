All the shaders in this directory branch come from Ogre engine.
http://www.ogre3d.org
