using System;
using System.Collections.Generic;
using System.Text;
using IScenePlugin;
using Microsoft.DirectX.Direct3D;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.DirectX;
using System.IO;
using System.Reflection;
using Microsoft.DirectX.AudioVideoPlayback;

namespace VideoScenePlugin
{
	public class VideoManager : Scene
	{
		private Device m_Device;

		private Color m_ClearColor;

		private string m_DataPath;
		private ICamera m_Camera;
		private VertexBuffer[] m_CubeFaces = new VertexBuffer[6];
		private Texture m_VideoTexture;
		private Video m_Video;

		private ICustomRenderTiming m_CustomRenderTiming;

		public override string Name
		{
			get
			{
				return ("Video Render Scene (Studio Post Effect)");
			}
		}

		public override void Initialize(ICamera camera, ScenePluginInitParams prms)
		{
			m_Camera = camera;
			m_Camera.Target = new Vector3();
			m_Camera.Position = new Vector3(0.0f, 0.0f, 8.0f);
			m_Camera.Update();

			prms.CustomRenderTiming.NeedCustomRenderTiming = true;
			prms.ShowGrid = ShowGridMode.Off;
			m_CustomRenderTiming = prms.CustomRenderTiming;
		}

		public override void Terminate()
		{
			m_Video.TextureReadyToRender -= new TextureRenderEventHandler(OnVideoTextureReadyToRender);
			m_Video.StopWhenReady();
			m_Video.Dispose();
			m_Video = null;
		}

		public override void OnDeviceInitialized(Device device)
		{
			m_Device = device;
			m_ClearColor = Color.FromArgb(77, 77, 69);

			string pluginPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
			m_DataPath = string.Format("{0}\\VideoRenderPlugin.textures", pluginPath);

			//m_Video = new Video(@"your video here", false);

			m_Video.TextureReadyToRender += new TextureRenderEventHandler(OnVideoTextureReadyToRender);
			m_Video.Ending += new EventHandler(OnVideoEnding);
			m_Video.Play();
			m_Video.RenderToTexture(device);
		}

		private void OnVideoEnding(object sender, EventArgs e)
		{
			Video v = (Video)sender;
			v.Stop();
			v.Play();
		}

		private void OnVideoTextureReadyToRender(object sender, TextureRenderEventArgs e)
		{
			m_VideoTexture = e.Texture;
			m_CustomRenderTiming.RequestRender();
		}

		private float m_CubeWidth;
		private float m_CubeHeight;

		public override void OnDeviceReset(Device device)
		{
			device.RenderState.CullMode = Cull.CounterClockwise;
			device.RenderState.ZBufferEnable = true;
			device.RenderState.ZBufferWriteEnable = true;

			m_CubeWidth = (float)device.Viewport.Width;
			m_CubeHeight = (float)device.Viewport.Height;

			if (m_CubeWidth >= m_CubeHeight)
			{
				m_CubeWidth /= m_CubeHeight;
				m_CubeHeight = 1.0f;
			}
			else
			{
				m_CubeHeight /= m_CubeWidth;
				m_CubeWidth = 1.0f;
			}

			InitCubesFaces(device);
		}

		private void InitCubesFaces(Device device)
		{
			for (int i = 0; i < 6; i++)
			{
				if (m_CubeFaces[i] != null)
					m_CubeFaces[i].Dispose();
				m_CubeFaces[i] = null;
			}

			CustomVertex.PositionTextured[] vertices = new CustomVertex.PositionTextured[6];

			// front
			vertices[0] = new CustomVertex.PositionTextured(+1.0f, +1.0f, 1.0f, 1.0f, 0.0f);
			vertices[1] = new CustomVertex.PositionTextured(+1.0f, -1.0f, 1.0f, 1.0f, 1.0f);
			vertices[2] = new CustomVertex.PositionTextured(-1.0f, -1.0f, 1.0f, 0.0f, 1.0f);
			vertices[3] = new CustomVertex.PositionTextured(+1.0f, +1.0f, 1.0f, 1.0f, 0.0f);
			vertices[4] = new CustomVertex.PositionTextured(-1.0f, -1.0f, 1.0f, 0.0f, 1.0f);
			vertices[5] = new CustomVertex.PositionTextured(-1.0f, +1.0f, 1.0f, 0.0f, 0.0f);

			m_CubeFaces[0] = new VertexBuffer(typeof(CustomVertex.PositionTextured), vertices.Length, device, Usage.Dynamic | Usage.WriteOnly, CustomVertex.PositionTextured.Format, Pool.Default);
			m_CubeFaces[0].SetData(vertices, 0, LockFlags.None);


			// back
			vertices[0] = new CustomVertex.PositionTextured(-1.0f, +1.0f, -1.0f, 1.0f, 0.0f);
			vertices[1] = new CustomVertex.PositionTextured(-1.0f, -1.0f, -1.0f, 1.0f, 1.0f);
			vertices[2] = new CustomVertex.PositionTextured(+1.0f, -1.0f, -1.0f, 0.0f, 1.0f);
			vertices[3] = new CustomVertex.PositionTextured(-1.0f, +1.0f, -1.0f, 1.0f, 0.0f);
			vertices[4] = new CustomVertex.PositionTextured(+1.0f, -1.0f, -1.0f, 0.0f, 1.0f);
			vertices[5] = new CustomVertex.PositionTextured(+1.0f, +1.0f, -1.0f, 0.0f, 0.0f);

			m_CubeFaces[1] = new VertexBuffer(typeof(CustomVertex.PositionTextured), vertices.Length, device, Usage.Dynamic | Usage.WriteOnly, CustomVertex.PositionTextured.Format, Pool.Default);
			m_CubeFaces[1].SetData(vertices, 0, LockFlags.None);


			// top
			vertices[0] = new CustomVertex.PositionTextured(+1.0f, +1.0f, -1.0f, 1.0f, 0.0f);
			vertices[1] = new CustomVertex.PositionTextured(+1.0f, +1.0f, +1.0f, 1.0f, 1.0f);
			vertices[2] = new CustomVertex.PositionTextured(-1.0f, +1.0f, +1.0f, 0.0f, 1.0f);
			vertices[3] = new CustomVertex.PositionTextured(+1.0f, +1.0f, -1.0f, 1.0f, 0.0f);
			vertices[4] = new CustomVertex.PositionTextured(-1.0f, +1.0f, +1.0f, 0.0f, 1.0f);
			vertices[5] = new CustomVertex.PositionTextured(-1.0f, +1.0f, -1.0f, 0.0f, 0.0f);

			m_CubeFaces[2] = new VertexBuffer(typeof(CustomVertex.PositionTextured), vertices.Length, device, Usage.Dynamic | Usage.WriteOnly, CustomVertex.PositionTextured.Format, Pool.Default);
			m_CubeFaces[2].SetData(vertices, 0, LockFlags.None);


			// bottom
			vertices[0] = new CustomVertex.PositionTextured(-1.0f, -1.0f, -1.0f, 0.0f, 1.0f);
			vertices[1] = new CustomVertex.PositionTextured(-1.0f, -1.0f, +1.0f, 0.0f, 0.0f);
			vertices[2] = new CustomVertex.PositionTextured(+1.0f, -1.0f, +1.0f, 1.0f, 0.0f);
			vertices[3] = new CustomVertex.PositionTextured(-1.0f, -1.0f, -1.0f, 0.0f, 1.0f);
			vertices[4] = new CustomVertex.PositionTextured(+1.0f, -1.0f, +1.0f, 1.0f, 0.0f);
			vertices[5] = new CustomVertex.PositionTextured(+1.0f, -1.0f, -1.0f, 1.0f, 1.0f);

			m_CubeFaces[3] = new VertexBuffer(typeof(CustomVertex.PositionTextured), vertices.Length, device, Usage.Dynamic | Usage.WriteOnly, CustomVertex.PositionTextured.Format, Pool.Default);
			m_CubeFaces[3].SetData(vertices, 0, LockFlags.None);


			// right
			vertices[0] = new CustomVertex.PositionTextured(+1.0f, +1.0f, -1.0f, 1.0f, 0.0f);
			vertices[1] = new CustomVertex.PositionTextured(+1.0f, -1.0f, -1.0f, 1.0f, 1.0f);
			vertices[2] = new CustomVertex.PositionTextured(+1.0f, -1.0f, +1.0f, 0.0f, 1.0f);
			vertices[3] = new CustomVertex.PositionTextured(+1.0f, +1.0f, -1.0f, 1.0f, 0.0f);
			vertices[4] = new CustomVertex.PositionTextured(+1.0f, -1.0f, +1.0f, 0.0f, 1.0f);
			vertices[5] = new CustomVertex.PositionTextured(+1.0f, +1.0f, +1.0f, 0.0f, 0.0f);

			m_CubeFaces[4] = new VertexBuffer(typeof(CustomVertex.PositionTextured), vertices.Length, device, Usage.Dynamic | Usage.WriteOnly, CustomVertex.PositionTextured.Format, Pool.Default);
			m_CubeFaces[4].SetData(vertices, 0, LockFlags.None);


			// left
			vertices[0] = new CustomVertex.PositionTextured(-1.0f, +1.0f, +1.0f, 1.0f, 0.0f);
			vertices[1] = new CustomVertex.PositionTextured(-1.0f, -1.0f, +1.0f, 1.0f, 1.0f);
			vertices[2] = new CustomVertex.PositionTextured(-1.0f, -1.0f, -1.0f, 0.0f, 1.0f);
			vertices[3] = new CustomVertex.PositionTextured(-1.0f, +1.0f, +1.0f, 1.0f, 0.0f);
			vertices[4] = new CustomVertex.PositionTextured(-1.0f, -1.0f, -1.0f, 0.0f, 1.0f);
			vertices[5] = new CustomVertex.PositionTextured(-1.0f, +1.0f, -1.0f, 0.0f, 0.0f);

			m_CubeFaces[5] = new VertexBuffer(typeof(CustomVertex.PositionTextured), vertices.Length, device, Usage.Dynamic | Usage.WriteOnly, CustomVertex.PositionTextured.Format, Pool.Default);
			m_CubeFaces[5].SetData(vertices, 0, LockFlags.None);
		}

		public override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.XButton1)
			{
				m_CameraToVideoCounter = 20;
				m_CameraTranslation = (new Vector3(0.0f, 0.0f, 3.5f) - m_Camera.Position) * (1.0f / (float)m_CameraToVideoCounter);
			}
		}

		public override void OnMouseMove(MouseEventArgs e)
		{
			if (e.Button != MouseButtons.Middle)
			{
				m_Camera.Update(e);
			}
		}

		private int m_CameraToVideoCounter = 0;
		private Vector3 m_CameraTranslation = new Vector3();

		public override void UpdateScene(double elapsedTime)
		{
			if (m_CameraToVideoCounter > 0)
			{
				m_Camera.Position += m_CameraTranslation;
				m_Camera.Update();
				m_CameraToVideoCounter--;
			}
		}

		public override void RenderScene(Device device)
		{
			device.Clear(ClearFlags.Target | ClearFlags.ZBuffer, m_ClearColor, 1.0f, 0);

			device.Transform.World = Matrix.Scaling(m_CubeWidth, m_CubeHeight, m_CubeWidth);

			device.VertexFormat = CustomVertex.PositionTextured.Format;
			device.SetTexture(0, m_VideoTexture);
			for (int i = 0; i < 6; i++)
			{
				device.SetStreamSource(0, m_CubeFaces[i], 0);
				device.DrawPrimitives(PrimitiveType.TriangleList, 0, 2);
			}

			device.Transform.World = Matrix.Identity;
		}
	}
}
