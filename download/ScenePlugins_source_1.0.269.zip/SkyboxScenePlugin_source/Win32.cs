using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace SkyboxScenePlugin
{
	public class Win32
	{
		[DllImport("msvcrt.dll")]
		public static extern IntPtr memcpy(IntPtr dst, IntPtr src, int count);
	}
}
